import 'slick-carousel/slick/slick'
import 'modules/SliderDemo'

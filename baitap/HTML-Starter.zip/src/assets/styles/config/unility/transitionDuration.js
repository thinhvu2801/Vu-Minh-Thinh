const transitionDuration = {
  DEFAULT: '150ms',
  0: '0ms',
  10: '10ms',
  50: '50ms',
  75: '75ms',
  100: '100ms',
  150: '150ms',
  200: '200ms',
  250: '250ms',
  300: '300ms',
  350: '350ms',
  400: '400ms',
  500: '500ms',
  600: '600ms',
  700: '700ms',
  800: '800ms',
  1000: '1000ms'
}
module.exports = {
  transitionDuration
}

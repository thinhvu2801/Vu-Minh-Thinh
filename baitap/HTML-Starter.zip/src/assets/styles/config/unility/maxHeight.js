const maxHeight = {
  '0': '0',
  '0.5': '1px',
  '200': '400px',
  full: '100%',
  screen: '100vh',
  initial: 'initial',
  'none': 'none',
  '2k': '2000px'
}
module.exports = {
  maxHeight
}

const BorderWidth = {
  DEFAULT: '1px',
  0: '0px',
  1: '1px',
  2: '2px',
  4: '4px',
  8: '8px'
}
module.exports = {
  BorderWidth
}

const minWidth = {
  0: '0',
  full: '100%',
  min: 'min-content',
  max: 'max-content',
  200: '200px'
}
module.exports = {
  minWidth
}
